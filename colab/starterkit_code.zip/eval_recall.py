"""Evaluate the shipped example model on train.py's validation split with Recall@K."""
import math
import sys
import time
from pathlib import Path

import torch

STARTER = Path(sys.argv[1])
sys.path.insert(0, str(STARTER))
from train import load_and_split  # noqa: E402
from sample_submission.model import load_model, predict  # noqa: E402

torch.set_num_threads(max(1, torch.get_num_threads()))
_, valid = load_and_split(STARTER / "haikuthon-train", 42)
queries = [{"prompt_id": r["id"], "prompt": r["prompts"]} for r in valid]
candidates = [{"image_id": r["id"], "image_path": r["image_path"]} for r in valid]

model = load_model(STARTER / "sample_submission", "cpu")
t0 = time.time()
preds = predict(model, queries, candidates, top_k=100)
print(f"predict time (CPU, {len(candidates)} images): {time.time() - t0:.1f}s")

ranks = []
for r in valid:
    ranking = preds[r["id"]]
    ranks.append(ranking.index(r["id"]) + 1 if r["id"] in ranking else None)

n = len(ranks)
def recall(k):
    return sum(1 for x in ranks if x is not None and x <= k) / n
ndcg5 = sum(1 / math.log2(x + 1) for x in ranks if x is not None and x <= 5) / n
r1 = recall(1)
print(f"Recall@1  {r1:.4f}")
print(f"NDCG@5    {ndcg5:.4f}")
print(f"Score     {(r1 + ndcg5) / 2:.4f}")
for k in (2, 3, 5, 10, 20, 30, 50, 100):
    print(f"Recall@{k:<3d} {recall(k):.4f}")
print("rank distribution (1..5, >5):",
      [sum(1 for x in ranks if x == i) for i in range(1, 6)],
      sum(1 for x in ranks if x is None or x > 5))
