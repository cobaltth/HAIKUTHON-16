"""평가 서버가 불러오는 2단계 검색 모델.

1단계: SigLIP 듀얼 인코더로 후보 전체에서 프롬프트마다 Top-K를 고릅니다.
2단계: BLIP-2 ITM(cross-encoder)이 Top-K의 각 (프롬프트, 이미지) 쌍을 다시 채점하고,
       두 점수를 쿼리별로 정규화해 가중합한 순서로 Top-5를 반환합니다.

reranker/ 폴더나 pipeline.json이 없으면 1단계만 사용합니다(기존 예제와 같은 동작).
"""

import json
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import torch
from PIL import Image
from torch.nn.functional import normalize
from transformers import AutoProcessor, Blip2ForImageTextRetrieval, SiglipModel


DEFAULT_CONFIG = {
    "rerank": False,             # true이고 reranker/ 폴더가 있을 때만 2단계를 실행합니다.
    "rerank_k": 5,               # 1단계에서 재정렬기로 넘길 후보 수
    "rerank_weight": 0.5,        # 최종 점수 = w × 재정렬 + (1 − w) × 1단계 (쿼리별 z-정규화 후)
    "rerank_text_tokens": 128,   # BLIP-2 텍스트 최대 토큰 수
    "rerank_image_batch": 128,   # BLIP-2 이미지 인코딩 배치
    "rerank_pair_batch": 256,    # BLIP-2 ITM 쌍 배치
    "time_budget_sec": 720,      # load_model 시작부터 이 시간이 지나면 재정렬을 멈추고 1단계 순위를 씁니다.
    "image_workers": 8,          # PNG 디코딩·전처리 스레드 수
}


def load_model(model_dir, device):
    start = time.monotonic()
    root = Path(model_dir)
    config = dict(DEFAULT_CONFIG)
    if (root / "pipeline.json").is_file():
        config.update(json.loads((root / "pipeline.json").read_text(encoding="utf-8")))

    # 서버가 전달한 ZIP 최상위 경로에서 models/ 폴더를 찾습니다.
    checkpoint_dir = root / "models"
    network = SiglipModel.from_pretrained(checkpoint_dir, local_files_only=True).to(device)
    if network.device.type == "cuda":
        network.half()
    processor = AutoProcessor.from_pretrained(checkpoint_dir, local_files_only=True)

    reranker = None
    if config["rerank"] and (root / "reranker").is_dir():
        reranker = load_reranker(root / "reranker", device)
    return {"siglip": network.eval(), "processor": processor, "reranker": reranker,
            "config": config, "start": start}


def load_reranker(path, device):
    # GPU에서는 fp16으로 불러옵니다. Q-Former는 transformers가 자동으로 fp32로 유지합니다.
    dtype = torch.float16 if torch.device(device).type == "cuda" else torch.float32
    blip = Blip2ForImageTextRetrieval.from_pretrained(path, dtype=dtype, local_files_only=True).to(device)
    processor = AutoProcessor.from_pretrained(path, local_files_only=True)
    return blip.eval(), processor


def read_image(path):
    with Image.open(path) as image:
        return image.convert("RGB")


def tokenize(processor, prompts):
    # SigLIP 사전 학습 때와 같은 길이로 패딩합니다. 마지막 위치의 토큰으로 문장을 요약하기 때문입니다.
    return processor(text=prompts, padding="max_length", truncation=True, return_tensors="pt")


def iter_pixel_batches(paths, image_processor, batch_size, workers):
    """이미지를 여러 스레드로 읽고 전처리합니다. 다음 배치를 미리 읽어 CPU와 GPU가 동시에 일합니다."""
    def load(path):
        return image_processor(images=read_image(path), return_tensors="pt").pixel_values[0]

    batches = [paths[i:i + batch_size] for i in range(0, len(paths), batch_size)]
    if not batches:
        return
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        upcoming = [pool.submit(load, path) for path in batches[0]]
        for index in range(len(batches)):
            current = upcoming
            if index + 1 < len(batches):
                upcoming = [pool.submit(load, path) for path in batches[index + 1]]
            yield torch.stack([future.result() for future in current])


# ---------------------------------------------------------------- 1단계: SigLIP 검색

def encode_images(model, paths, batch_size=64):
    network, processor = model["siglip"], model["processor"]
    vectors = []
    for pixels in iter_pixel_batches(paths, processor.image_processor, batch_size, model["config"]["image_workers"]):
        pixels = pixels.to(device=network.device, dtype=network.dtype)
        features = network.get_image_features(pixel_values=pixels).pooler_output
        vectors.append(normalize(features.float(), dim=-1))
    return torch.cat(vectors)


def encode_texts(model, prompts, batch_size=128):
    network, processor = model["siglip"], model["processor"]
    vectors = []
    for start in range(0, len(prompts), batch_size):
        tokens = tokenize(processor, prompts[start:start + batch_size]).to(network.device)
        features = network.get_text_features(**tokens).pooler_output
        vectors.append(normalize(features.float(), dim=-1))
    return torch.cat(vectors)


def retrieve(model, queries, candidates, k):
    """프롬프트마다 코사인 유사도 Top-k의 (점수, 후보 인덱스)를 반환합니다."""
    # 모든 프롬프트가 같은 후보 풀을 사용하므로 이미지는 한 번만 인코딩합니다.
    image_vectors = encode_images(model, [item["image_path"] for item in candidates])
    text_vectors = encode_texts(model, [item["prompt"] for item in queries])
    scores, indices = [], []
    for start in range(0, len(text_vectors), 1024):
        top = (text_vectors[start:start + 1024] @ image_vectors.T).topk(k, dim=1)
        scores.append(top.values)
        indices.append(top.indices)
    return torch.cat(scores), torch.cat(indices)


# ---------------------------------------------------------------- 2단계: BLIP-2 재정렬

def blip_tokenize(processor, texts, max_tokens):
    # Blip2Processor는 이미지 토큰을 앞에 붙일 수 있어서, 순수 텍스트 토큰만 쓰도록 토크나이저를 직접 호출합니다.
    return processor.tokenizer(texts, padding="longest", truncation=True, max_length=max_tokens,
                               return_tensors="pt")


def blip_image_embeds(blip, pixels):
    """ViT-g 패치 특징 (N, 257, 1408). 이미지마다 한 번만 계산해 여러 프롬프트와의 비교에 재사용합니다."""
    pixels = pixels.to(device=blip.device, dtype=blip.vision_model.embeddings.patch_embedding.weight.dtype)
    return blip.vision_model(pixel_values=pixels).last_hidden_state


def itm_scores(blip, image_embeds, input_ids, attention_mask):
    """BLIP-2 ITM 점수(일치 logit − 불일치 logit).

    Blip2ForImageTextRetrieval.forward의 ITM 분기와 같은 계산이지만,
    미리 계산한 이미지 특징을 받아 ViT-g를 다시 돌리지 않습니다.
    """
    query_tokens = blip.query_tokens.expand(image_embeds.shape[0], -1, -1)
    query_mask = torch.ones(query_tokens.shape[:2], dtype=attention_mask.dtype, device=attention_mask.device)
    image_mask = torch.ones(image_embeds.shape[:2], dtype=torch.long, device=image_embeds.device)
    embeds = blip.embeddings(input_ids=input_ids, query_embeds=query_tokens)
    hidden = blip.qformer(
        query_embeds=embeds,
        query_length=query_tokens.shape[1],
        attention_mask=torch.cat([query_mask, attention_mask], dim=1),
        encoder_hidden_states=image_embeds,
        encoder_attention_mask=image_mask,
        return_dict=True,
    ).last_hidden_state
    logits = blip.itm_head(hidden[:, :query_tokens.shape[1]].to(blip.itm_head.weight.dtype)).mean(dim=1)
    return (logits[:, 1] - logits[:, 0]).float()


def rerank(model, queries, candidates, indices, deadline):
    """Top-K 쌍마다 ITM 점수를 매깁니다. 시간이 다 되면 멈추고, 못 채운 칸은 NaN으로 남깁니다."""
    blip, blip_processor = model["reranker"]
    config = model["config"]
    scores = torch.full(indices.shape, float("nan"))
    tokens = blip_tokenize(blip_processor, [item["prompt"] for item in queries],
                           config["rerank_text_tokens"]).to(blip.device)

    # 쌍을 이미지 기준으로 묶어, 무거운 ViT-g 인코딩을 이미지당 한 번만 합니다.
    pairs_by_image = defaultdict(list)
    for query_index, row in enumerate(indices.tolist()):
        for slot, image_index in enumerate(row):
            pairs_by_image[image_index].append((query_index, slot))
    image_list = sorted(pairs_by_image)
    paths = [candidates[index]["image_path"] for index in image_list]

    image_batch, pair_batch = config["rerank_image_batch"], config["rerank_pair_batch"]
    batches = iter_pixel_batches(paths, blip_processor.image_processor, image_batch, config["image_workers"])
    for chunk, pixels in enumerate(batches):
        if time.monotonic() > deadline:
            break
        embeds = blip_image_embeds(blip, pixels)
        chunk_images = image_list[chunk * image_batch:(chunk + 1) * image_batch]
        pairs = [(local, query_index, slot)
                 for local, image_index in enumerate(chunk_images)
                 for query_index, slot in pairs_by_image[image_index]]
        for start in range(0, len(pairs), pair_batch):
            local, query_index, slot = (torch.tensor(column) for column in zip(*pairs[start:start + pair_batch]))
            rows = query_index.to(blip.device)
            values = itm_scores(blip, embeds[local.to(blip.device)],
                                tokens.input_ids[rows], tokens.attention_mask[rows])
            scores[query_index, slot] = values.cpu()
    return scores


# ---------------------------------------------------------------- 점수 결합

def zscore(values):
    return (values - values.mean(dim=1, keepdim=True)) / (values.std(dim=1, keepdim=True) + 1e-6)


def fuse(stage1, rerank_scores, weight):
    """쿼리별로 두 점수를 z-정규화해 가중합합니다. 재정렬을 끝내지 못한 쿼리는 1단계 점수만 씁니다."""
    if stage1.shape[1] < 2:
        return stage1
    fused = zscore(stage1)
    if rerank_scores is None or weight <= 0:
        return fused
    done = ~torch.isnan(rerank_scores).any(dim=1)
    if done.any():
        fused[done] = (1 - weight) * fused[done] + weight * zscore(rerank_scores[done])
    return fused


def score_candidates(model, queries, candidates, top_k=5):
    """(후보 인덱스, 1단계 점수, 재정렬 점수 또는 None)을 반환합니다. 검증에서 가중치를 고를 때도 씁니다."""
    config = model["config"]
    use_rerank = model.get("reranker") is not None
    k = min(len(candidates), max(top_k, config["rerank_k"] if use_rerank else top_k))
    stage1, indices = retrieve(model, queries, candidates, k)
    rerank_scores = None
    if use_rerank:
        deadline = model.get("start", time.monotonic()) + config["time_budget_sec"]
        rerank_scores = rerank(model, queries, candidates, indices, deadline)
    return indices.cpu(), stage1.cpu(), rerank_scores


def rank(indices, stage1, rerank_scores, weight, top_k):
    """결합 점수 순서로 정렬한 후보 인덱스 (Q, top_k)."""
    fused = fuse(stage1, rerank_scores, weight)
    order = fused.topk(min(top_k, fused.shape[1]), dim=1).indices
    return indices.gather(1, order)


@torch.inference_mode()
def predict(model, queries, candidates, top_k=5):
    model["siglip"].eval()
    if model.get("reranker") is not None:
        model["reranker"][0].eval()
    indices, stage1, rerank_scores = score_candidates(model, queries, candidates, top_k)
    chosen = rank(indices, stage1, rerank_scores, model["config"]["rerank_weight"], top_k)
    image_ids = [item["image_id"] for item in candidates]
    return {query["prompt_id"]: [image_ids[index] for index in row]
            for query, row in zip(queries, chosen.tolist())}
