"""공개 학습 데이터 분할 → 1단계 SigLIP 학습 → 2단계 BLIP-2 재정렬기 학습 → 검증 → 제출 폴더 저장."""

import argparse
import contextlib
import functools
import json
import math
import random
import re
import shutil
import tempfile
import time
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

import torch
import torch.nn.functional as F
import torch.utils.checkpoint
from tqdm import tqdm
from transformers import AutoProcessor, Blip2ForImageTextRetrieval, SiglipModel

from sample_submission.model import (
    DEFAULT_CONFIG,
    blip_image_embeds,
    blip_tokenize,
    encode_images,
    encode_texts,
    itm_scores,
    iter_pixel_batches,
    rank,
    read_image,
    score_candidates,
    tokenize,
)


MODEL_ID = "google/siglip-base-patch16-224"
RERANKER_ID = "Salesforce/blip2-itm-vit-g"
DEFAULT_SUBMISSION_DIR = Path(__file__).resolve().parent / "sample_submission"
FUSION_WEIGHTS = [round(0.1 * step, 1) for step in range(11)]   # 재정렬 점수 가중치 후보 0.0 ~ 1.0


# ---------------------------------------------------------------- 데이터

def load_and_split(data_dir, seed):
    # id는 네 자리 문자열로 보관합니다. 정렬할 때만 숫자로 변환합니다.
    with (data_dir / "prompts.jsonl").open(encoding="utf-8") as file:
        rows = [json.loads(line) for line in file if line.strip()]
    rows.sort(key=lambda row: int(row["id"]))
    ids = [row["id"] for row in rows]
    if len(set(ids)) != len(rows):
        raise ValueError("prompts.jsonl에 중복된 id가 있습니다.")
    for row in rows:
        row["image_path"] = data_dir / "images" / (row["id"] + ".png")
        if not row["image_path"].is_file():
            raise FileNotFoundError(row["image_path"])

    # 무작위로 정하는 것은 소속뿐입니다. 두 목록은 모두 원래 id 순서를 유지합니다.
    n_train = len(rows) * 8 // 10
    if n_train == 0 or len(rows) - n_train < 5:
        raise ValueError("학습 데이터와 Top-5 검증용 이미지 5장 이상이 필요합니다.")
    train_ids = set(random.Random(seed).sample(ids, n_train))
    train = [row for row in rows if row["id"] in train_ids]
    valid = [row for row in rows if row["id"] not in train_ids]
    return train, valid


# ---------------------------------------------------------------- 텍스트 하드 네거티브
# 데이터는 사물·장면·스타일·시점·조명이 같은 형제 그룹(최대 8개)입니다. 학습 데이터의 형제 8,132쌍을 비교하면
#   - 다른 항목 수: 한 가지 36%, 두 가지 47%(색 + 관계 24%가 가장 흔함), 세 가지 이상 16%
#   - 색 58%(값 변경 30%, 사물끼리 맞바꿈 28%), 관계 방향 뒤집힘 26%, 자세 20%, 개수 12%(대부분 사물끼리 맞바꿈),
#     무늬 11%, 관계 종류 10%, 재질 6%, 열림/닫힘 3%, 모양 2% — 스타일·시점·조명은 형제끼리 같습니다.
# 그래서 이 항목들을 한 가지·두 가지씩 바꾼 문장을 위 비율대로 만들고, 형제의 실제 프롬프트(text_pool)도 오답으로 씁니다.
# 문법이 어색한 오답은 모델이 내용 대신 문법으로 구분하는 지름길이 되므로, 문법을 맞출 수 있을 때만 만듭니다.

COLORS = ["red", "orange", "yellow", "green", "blue", "purple", "pink", "brown", "black", "white", "gray", "beige"]
PATTERNS = ["solid-colored", "polka-dotted", "striped", "checkered", "floral", "zigzag-patterned"]
# 자세는 -ing형만 바꿉니다. sits/stands/lies는 사물에 '놓여 있다'는 뜻으로 주로 쓰여(the ball sits next to …),
# 바꿔도 사실이 달라지지 않을 수 있습니다. sleeping은 'sleeping bag'에만 쓰여 뺐습니다.
POSE_GERUNDS = ["standing", "sitting", "lying", "crouching", "kneeling"]
PERSON_ONLY_POSES = {"crouching", "kneeling"}   # 데이터에서 사람에게만 쓰입니다. 동물에 붙이면 문장만 보고도 틀린 걸 알 수 있습니다.
STATES = ["open", "closed"]
MATERIALS = ["metal", "plastic", "wooden", "ceramic"]
SHAPES = ["square", "round", "oval", "triangular", "hexagonal", "rectangular", "star-shaped"]
RELATION_PAIRS = [("left", "right"), ("above", "below")]
# 관계 종류 바꾸기: 세로(위·아래·위에 얹힘)와 가로(왼쪽·오른쪽·옆) 사이에서만 바꿉니다.
# 같은 축끼리(on ↔ above, left ↔ next to)는 한쪽이 다른 쪽을 포함할 수 있어 오답이 오히려 참일 수 있습니다.
# 'on'은 바꿀 대상으로만 쓰고 결과로는 만들지 않습니다('shelf is on one cookie'처럼 문장만 봐도 틀린 장면이 됩니다).
VERTICAL_RELATIONS = ["above", "below"]
HORIZONTAL_RELATIONS = ["to the left of", "to the right of", "next to"]
# 형제 쌍 분석에서 각 항목이 다른 비율. 오답 종류를 이 비율대로 뽑습니다(관계 종류 바꾸기처럼 만들기 쉬운 것이 몰리지 않게).
KIND_WEIGHT = {"color": 0.58, "relation flip": 0.26, "pose": 0.20, "count": 0.12, "pattern": 0.11,
               "relation type": 0.10, "material": 0.06, "state": 0.03, "shape": 0.02}
_RELATION_TARGET = re.compile(r"(?<![\w-])(to the left of|to the right of|next to|above|below|on)"
                              r"(?=\s+(?:one|two|three|the|a single)\b)", re.IGNORECASE)

# 개수 바꾸기(one ↔ two)용. 명사구는 숫자 뒤에서 이 단어나 문장부호를 만나면 끝납니다.
_PHRASE_END = set("""is are and to above below next on in inside that which with while under behind beside near at
from for rests resting rest sits sitting sit stands standing stand lies lying lie holds holding hold wears wearing
wear kneels kneeling crouches crouching appears appear shows show present placed shown viewed together alongside""".split())
# 명사구 앞이 이 단어면 목적어라서, 뒤 동사의 수를 맞출 필요가 없습니다.
_OBJECT_PREV = {"above", "below", "of", "on", "to", "with", "beside", "near", "inside", "under", "behind",
                "holds", "holding", "wears", "wearing"}
_IRREGULAR_PLURALS = {"person": "people", "man": "men", "woman": "women", "child": "children", "mouse": "mice",
                      "goose": "geese", "foot": "feet", "tooth": "teeth", "cactus": "cacti"}
_TOKEN = re.compile(r"[A-Za-z][A-Za-z-]*|[^\sA-Za-z]")


def build_noun_forms(prompts):
    """학습 프롬프트에 단수·복수가 둘 다 나오는 명사만 {단수: 복수}로 모읍니다. 데이터에 없는 복수형은 만들지 않습니다."""
    vocab = {word for prompt in prompts for word in re.findall(r"[a-z]+", prompt.lower())}
    forms = {}
    for word in vocab:
        if len(word) < 3:
            continue
        candidates = [_IRREGULAR_PLURALS.get(word), word + "s", word + "es"]
        if word.endswith("y") and word[-2:-1] not in "aeiou":
            candidates.append(word[:-1] + "ies")
        if word.endswith("f"):
            candidates.append(word[:-1] + "ves")
        if word.endswith("fe"):
            candidates.append(word[:-2] + "ves")
        plural = next((form for form in candidates if form and form != word and form in vocab), None)
        if plural:
            forms[word] = plural
    return forms


# 개수를 바꿀 때 명사 바로 뒤 동사의 수를 맞춥니다(3인칭 단수 ↔ 복수).
_VERB_PLURAL = {"is": "are", "rests": "rest", "sits": "sit", "stands": "stand", "lies": "lie", "holds": "hold",
                "wears": "wear", "appears": "appear", "kneels": "kneel", "crouches": "crouch", "rides": "ride",
                "has": "have", "hangs": "hang", "leans": "lean", "floats": "float", "faces": "face",
                "contains": "contain"}
_VERB_SINGULAR = {plural: single for single, plural in _VERB_PLURAL.items()}
_NUMBERS = ("one", "two", "three", "single")


def _verb_edit(tokens, words, k, plural):
    """k번째 토큰이 동사면 수에 맞춘 편집 하나를, 동사가 아니면 None을 돌려줍니다."""
    if k >= len(words):
        return None
    table = _VERB_PLURAL if plural else _VERB_SINGULAR
    if words[k] in table:
        return [(tokens[k].start(), tokens[k].end(), _match_case(table[words[k]], tokens[k].group(0)))]
    if words[k] in (_VERB_SINGULAR if plural else _VERB_PLURAL):
        return []   # 이미 맞는 수
    return None


def _count_edits(prompt, noun_forms):
    """'one 명사구' ↔ 'two 명사구'로 바꿀 수 있는 곳마다 (방향, 편집 목록)을 돌려줍니다.

    문법을 지킬 수 있을 때만 고릅니다.
    - 주어 자리: 명사구 바로 뒤 동사(is, rests, sits …)의 수를 함께 바꿉니다. 바로 뒤가 동사가 아니면 건너뜁니다.
    - 목적어 자리(앞이 전치사·holds 등): 뒤 동사는 바깥 주어의 것이라 그대로 두고, 'that/which is' 관계절만 맞춥니다.
    - 같은 명사를 다시 가리키는 곳('The robot toy is …')도 단수·복수와 바로 뒤 동사를 함께 바꿉니다.
      같은 이름의 사물이 따로 소개되거나('one scarf … one scarf'), 명사가 다른 명사를 꾸미거나, 뒤가 쉼표 등이라
      동사를 확정할 수 없으면 건너뜁니다.
    """
    if not noun_forms:
        return []
    singular_of = {plural: singular for singular, plural in noun_forms.items()}
    tokens = list(_TOKEN.finditer(prompt))
    words = [token.group(0).lower() for token in tokens]
    found = []
    for i, number in enumerate(words):
        if number not in ("one", "two"):
            continue
        end = i + 1
        while end < len(words) and end - i <= 5 and words[end][0].isalpha() and words[end] not in _PHRASE_END:
            end += 1
        phrase = range(i + 1, end)
        if not phrase:
            continue
        of = next((k for k in phrase if words[k] == "of"), None)   # 'wedges of cheese'의 중심 명사는 wedges
        head = of - 1 if of is not None else end - 1
        noun = words[head]
        if head <= i:
            continue
        if number == "one" and noun in noun_forms:
            new_number, new_noun = "two", noun_forms[noun]
        elif number == "two" and noun in singular_of:
            new_number, new_noun = "one", singular_of[noun]
        else:
            continue
        plural = new_number == "two"
        # 'One of two tables, both gray'처럼 여럿을 전제한 표현은 숫자만 바꾸면 말이 안 됩니다.
        if (i >= 2 and words[i - 1] == "of" and words[i - 2] in ("one", "each", "both", "either", "neither")) \
                or "both" in words[end:end + 3]:
            continue
        edits = [(tokens[i].start(), tokens[i].end(), _match_case(new_number, tokens[i].group(0))),
                 (tokens[head].start(), tokens[head].end(), _match_case(new_noun, tokens[head].group(0)))]
        following = words[end] if end < len(words) else ""
        if i > 0 and words[i - 1] in _OBJECT_PREV:
            # 목적어: 바로 뒤 동사는 바깥 주어의 것('… resting on two shelves is next to …'). 관계절만 맞춥니다.
            if following in ("that", "which"):
                verb = _verb_edit(tokens, words, end + 1, plural)
                if verb is None:
                    continue
                edits += verb
        else:
            verb = _verb_edit(tokens, words, end, plural)
            if not verb:   # 주어인데 바로 뒤가 바꿀 동사가 아니면 수를 맞출 수 없습니다.
                continue
            edits += verb
        # 같은 명사를 다시 가리키는 곳
        ok = True
        for k, word in enumerate(words):
            if k == head or word not in (noun, new_noun):
                continue
            j = k - 1   # 명사구 앞쪽으로 거슬러 올라가 'the'나 경계까지
            while j >= 0 and k - j <= 5 and words[j][0].isalpha() and words[j] not in _PHRASE_END and words[j] != "the":
                if words[j] in _NUMBERS:
                    ok = False   # 같은 이름의 사물이 따로 소개됨('one scarf … one scarf')
                j -= 1
            after = words[k + 1] if k + 1 < len(words) else "."
            if not ok or j < 0 or words[j] != "the" or (after[0].isalpha() and after not in _PHRASE_END):
                ok = False       # 'the'로 가리키는 경우만 다룹니다. 다른 명사를 꾸미는 자리('glass vase')도 건너뜁니다.
                break
            before = words[j - 1] if j > 0 else "."
            edits.append((tokens[k].start(), tokens[k].end(), _match_case(new_noun, tokens[k].group(0))))
            if after in ("that", "which"):
                verb = _verb_edit(tokens, words, k + 2, plural)
            elif before in _OBJECT_PREV or after in (".", ";", "and"):
                verb = []        # 목적어이거나 문장 끝·'A and B' 주어: 바꿀 동사가 없습니다.
            else:
                verb = _verb_edit(tokens, words, k + 1, plural) or None   # 주어: 바로 뒤가 동사여야 합니다.
            if verb is None:
                ok = False
                break
            edits += verb
        if ok:
            found.append((f"{number}->{new_number}", edits))
    return found


def _term_pattern(terms):
    # 긴 표현을 먼저 시도해 "clay-style 3D render" 안의 "3D render"만 바뀌는 일을 막습니다.
    words = sorted(terms, key=len, reverse=True)
    return re.compile("|".join(rf"(?<![\w-]){re.escape(word)}(?![\w-])" for word in words), re.IGNORECASE)


def _match_case(new, old):
    return new[0].upper() + new[1:] if old[:1].isupper() else new


def _rewrite(text, edits):
    """(시작, 끝, 새 표현) 목록을 적용하고, 바뀐 표현 바로 앞의 a/an을 맞춥니다."""
    out, cursor = "", 0
    for start, end, new in sorted(edits):
        out += text[cursor:start]
        article = re.search(r"(?<![\w-])(an?)(\s+)$", out, re.IGNORECASE)
        if article:
            fixed = "an" if new[:1].lower() in "aeiou" else "a"
            fixed = _match_case(fixed, article.group(1))
            out = out[:article.start(1)] + fixed + article.group(2)
        out += new
        cursor = end
    return out + text[cursor:]


def _swap(text, first, second):
    """두 표현의 위치를 모두 맞바꿉니다. 예: left ↔ right, 빨강 ↔ 파랑(색 바인딩 교체)."""
    edits = []
    for match in _term_pattern([first, second]).finditer(text):
        new = second if match.group(0).lower() == first.lower() else first
        edits.append((match.start(), match.end(), _match_case(new, match.group(0))))
    return _rewrite(text, edits)


def _replace_one(text, terms, rng):
    """같은 종류의 표현 하나를 다른 값으로 바꿉니다. 예: watercolor painting → oil painting."""
    matches = list(_term_pattern(terms).finditer(text))
    if not matches:
        return None
    match = rng.choice(matches)
    current = match.group(0).lower()
    present = {m.group(0).lower() for m in matches}
    # 포함 관계인 표현(3D render ↔ clay-style 3D render)이나 이미 문장에 있는 값은 고르지 않습니다.
    options = [term for term in terms
               if term.lower() not in present and term.lower() not in current and current not in term.lower()]
    if not options:
        return None
    return _rewrite(text, [(match.start(), match.end(), _match_case(rng.choice(options), match.group(0)))])


def _pose_negatives(prompt, rng):
    """자세 교체(두 주체의 자세 맞바꾸기)와 치환(자세 하나 바꾸기). 사람 전용 자세는 사람 자세끼리만 오갑니다."""
    matches = list(_term_pattern(POSE_GERUNDS).finditer(prompt))
    if not matches:
        return []
    present = sorted({m.group(0).lower() for m in matches})
    out = []
    for group in ([p for p in present if p not in PERSON_ONLY_POSES], [p for p in present if p in PERSON_ONLY_POSES]):
        if len(group) >= 2:
            out.append(("pose swap", _swap(prompt, *rng.sample(group, 2))))
    match = rng.choice(matches)
    current = match.group(0).lower()
    options = [pose for pose in POSE_GERUNDS
               if pose not in present and (current in PERSON_ONLY_POSES or pose not in PERSON_ONLY_POSES)]
    if options:
        new = _match_case(rng.choice(options), match.group(0))
        out.append(("pose change", _rewrite(prompt, [(match.start(), match.end(), new)])))
    return out


def _relation_type_negative(prompt, rng):
    """관계 하나를 다른 축의 관계로 바꿉니다. 예: 'is next to one chair' → 'is above one chair'."""
    matches = list(_RELATION_TARGET.finditer(prompt))
    if not matches:
        return None
    match = rng.choice(matches)
    current = match.group(1).lower()
    options = HORIZONTAL_RELATIONS if current in VERTICAL_RELATIONS + ["on"] else VERTICAL_RELATIONS
    return _rewrite(prompt, [(match.start(1), match.end(1), _match_case(rng.choice(options), match.group(1)))])


def _material_change(prompt, rng):
    """재질 하나를 바꿉니다. 'made of beige plastic'처럼 명사로 쓰인 자리에는 wooden 대신 wood를 넣습니다."""
    matches = list(_term_pattern(MATERIALS).finditer(prompt))
    if not matches:
        return None
    match = rng.choice(matches)
    present = {m.group(0).lower() for m in matches}
    options = [term for term in MATERIALS if term not in present]
    if not options:
        return None
    new = rng.choice(options)
    rest = prompt[match.end():].lstrip()
    if new == "wooden" and (not rest or not rest[0].isalpha() or rest.split()[0].lower() in ("is", "and", "with")):
        new = "wood"
    return _rewrite(prompt, [(match.start(), match.end(), _match_case(new, match.group(0)))])


def _kind_weight(kind):
    return KIND_WEIGHT.get(kind if kind.startswith("relation") else kind.split()[0], 0.05)


def _weighted_order(items, rng):
    """(종류, 문장) 목록을 종류 가중치에 비례한 확률로 섞습니다(가중 무작위 비복원 추출)."""
    return sorted(items, key=lambda item: rng.random() ** (1 / _kind_weight(item[0])), reverse=True)


def single_edits(prompt, rng, noun_forms=None):
    """한 가지만 바꾼 오답 문장 [(종류, 문장)]. 형제 분석에서 실제로 다른 항목들입니다.

    교체형(단어는 그대로, 연결만 바뀜): 좌우·위아래 뒤집기, 두 사물의 색·무늬·재질·모양·열림/닫힘·자세 맞바꾸기, 두 사물의 개수 맞바꾸기
    치환형(한 단어만 바뀜): 색·무늬·재질·모양·열림/닫힘·자세 하나 바꾸기, one ↔ two, 관계 종류(가로 ↔ 세로)
    """
    out = []
    for first, second in RELATION_PAIRS:
        if _term_pattern([first, second]).search(prompt):
            out.append(("relation flip", _swap(prompt, first, second)))
    out.append(("relation type", _relation_type_negative(prompt, rng)))
    for name, terms in (("color", COLORS), ("pattern", PATTERNS), ("state", STATES), ("material", MATERIALS),
                        ("shape", SHAPES)):
        present = sorted({m.group(0).lower() for m in _term_pattern(terms).finditer(prompt)})
        if len(present) >= 2:
            out.append((f"{name} swap", _swap(prompt, *rng.sample(present, 2))))
        changed = _material_change(prompt, rng) if name == "material" else _replace_one(prompt, terms, rng)
        out.append((f"{name} change", changed))
    out += _pose_negatives(prompt, rng)
    counts = _count_edits(prompt, noun_forms)
    if counts:
        out.append(("count change", _rewrite(prompt, rng.choice(counts)[1])))
        ups = [edits for kind, edits in counts if kind == "one->two"]
        downs = [edits for kind, edits in counts if kind == "two->one"]
        if ups and downs:
            up, down = rng.choice(ups), rng.choice(downs)
            if not {start for start, _, _ in up} & {start for start, _, _ in down}:
                out.append(("count swap", _rewrite(prompt, up + down)))
    seen, unique = {prompt}, []
    for kind, text in out:
        if text and text not in seen and "standing down" not in text.lower():
            seen.add(text)
            unique.append((kind, text))
    return unique


def make_text_negatives(prompt, rng, count, noun_forms=None, double_ratio=0.5, with_kind=False):
    """정답 이미지와 어긋나는 문장을 최대 count개 만듭니다.

    형제 쌍은 한 가지만 다른 경우가 36%, 두 가지가 함께 다른 경우가 47%(색 + 관계 24%가 가장 흔함)라서,
    약 double_ratio만큼은 서로 다른 종류의 변경 두 가지를 겹친 문장으로 만듭니다.
    """
    if count <= 0:
        return []
    singles = _weighted_order(single_edits(prompt, rng, noun_forms), rng)
    if not singles:
        return []
    doubles, used = [], {prompt}
    want_doubles = round(count * double_ratio)
    for kind, text in singles:
        if len(doubles) >= want_doubles:
            break
        group = kind.split()[0]
        seconds = [(k, t) for k, t in single_edits(text, rng, noun_forms) if k.split()[0] != group and t not in used]
        if seconds:
            second_kind, second = _weighted_order(seconds, rng)[0]
            doubles.append((f"{kind} + {second_kind}", second))
            used.add(second)
    chosen = doubles + [item for item in singles if item[1] not in used][: count - len(doubles)]
    rng.shuffle(chosen)
    chosen = chosen[:count]
    return chosen if with_kind else [text for _, text in chosen]


# ---------------------------------------------------------------- 평가

def ranking_metrics(chosen, answer):
    """chosen: (Q, 5) 후보 인덱스, answer: (Q, 1) 정답 인덱스."""
    hit = chosen[:, :5] == answer
    found = hit.any(dim=1)
    position = hit.float().argmax(dim=1) + 1
    recall1 = hit[:, 0].float().mean().item()
    ndcg = torch.where(found, 1 / torch.log2(position.float() + 1), torch.zeros(len(hit))).mean().item()
    ranks = [int(((position == r) & found).sum()) for r in range(1, 6)] + [int((~found).sum())]
    return {"recall@1": recall1, "ndcg@5": ndcg, "score": (recall1 + ndcg) / 2,
            "recall@5": found.float().mean().item(), "ranks": ranks, "top1": hit[:, 0]}


def evaluate(model, rows, gallery_rows=(), weights=(0.0,)):
    """검증 프롬프트마다 [검증 이미지 + gallery_rows 이미지]를 후보로 두고, 제출용과 같은 점수 함수로 가중치별 성능을 잽니다.

    데이터는 '한 가지만 다른 형제 이미지' 그룹(최대 8장)으로 이루어져 있고, 무작위 분할로 형제 대부분이 학습 쪽에 들어갑니다.
    검증 이미지 800장만 후보로 두면 헷갈릴 형제가 거의 없어 점수가 부풀려집니다(1단계 R@5 1.00, 공개 테스트 0.46).
    그래서 학습 이미지를 오답 후보로 함께 넣어 형제를 되돌립니다. 정답은 항상 해당 검증 이미지입니다.
    반환: (가중치별 지표, 1단계 Recall@k 사전 — k는 1단계가 넘긴 후보 수 이하)
    """
    queries = [{"prompt_id": row["id"], "prompt": row["prompts"]} for row in rows]
    # 검증 이미지를 맨 앞에 두어 i번째 프롬프트의 정답 후보 인덱스가 i가 되게 합니다.
    candidates = [{"image_id": row["id"], "image_path": row["image_path"]} for row in [*rows, *gallery_rows]]
    model["start"] = time.monotonic()
    model["siglip"].eval()
    if model.get("reranker") is not None:
        model["reranker"][0].eval()
    with torch.inference_mode():
        indices, stage1, rerank_scores = score_candidates(model, queries, candidates)
    answer = torch.arange(len(rows)).unsqueeze(1)
    # indices는 1단계 점수 내림차순이므로, 앞의 k칸에 정답이 있으면 1단계 Recall@k입니다. --rerank-k를 고를 때 봅니다.
    hits = indices == answer
    depth = indices.shape[1]
    stage1_recall = {k: hits[:, :k].any(dim=1).float().mean().item()
                     for k in sorted({k for k in (5, 10, 15, 20, 30, 50) if k <= depth} | {depth})}
    results = {}
    for weight in (weights if rerank_scores is not None else (0.0,)):
        results[weight] = ranking_metrics(rank(indices, stage1, rerank_scores, weight, 5), answer)
    return results, stage1_recall


def describe(metrics):
    return (f"Recall@1 {metrics['recall@1']:.4f} | NDCG@5 {metrics['ndcg@5']:.4f} | "
            f"평균 {metrics['score']:.4f} | Recall@5 {metrics['recall@5']:.4f} | "
            f"정답 순위 1~5위/밖 {metrics['ranks']}")


# ---------------------------------------------------------------- 저장

def _replace_dir(source, target):
    if target.exists():
        for license_file in target.glob("LICENSE*"):   # 함께 배포하던 라이선스 파일은 유지합니다.
            shutil.copy2(license_file, source / license_file.name)
        shutil.rmtree(target)
    shutil.move(str(source), str(target))


def save_pretrained_dir(saveables, target):
    # 새 체크포인트가 모두 기록된 뒤 제출 폴더를 교체합니다. 중간에 멈춰도 기존 폴더가 깨지지 않습니다.
    with tempfile.TemporaryDirectory(dir=target.parent) as directory:
        folder = Path(directory) / "new"
        for item in saveables:
            item.save_pretrained(folder)
        _replace_dir(folder, target)


def write_pipeline(submission_dir, config):
    (submission_dir / "pipeline.json").write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n",
                                                  encoding="utf-8")


def make_zip(submission_dir, output):
    # 제출 폴더의 내용을 ZIP 최상위에 담습니다. 재정렬기를 쓰지 않으면 reranker/는 넣지 않습니다.
    pipeline = submission_dir / "pipeline.json"
    use_rerank = pipeline.is_file() and json.loads(pipeline.read_text(encoding="utf-8")).get("rerank", False)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as directory:
        archive = Path(directory) / "submission.zip"
        with ZipFile(archive, "w") as submission:
            for file in sorted(submission_dir.rglob("*")):
                relative = file.relative_to(submission_dir)
                if not file.is_file() or "__pycache__" in relative.parts or file.name == ".DS_Store":
                    continue
                if relative.parts[0] == "reranker" and not use_rerank:
                    continue
                submission.write(file, arcname=relative)
        archive.replace(output)


def prepare_submission_dir(submission_dir):
    submission_dir.mkdir(parents=True, exist_ok=True)
    for name in ("model.py", "requirements.txt"):
        if not (submission_dir / name).exists():
            shutil.copy2(DEFAULT_SUBMISSION_DIR / name, submission_dir / name)


# ---------------------------------------------------------------- 1단계: SigLIP

def train_siglip_epoch(network, processor, rows, optimizer, batch_size):
    network.train()
    total_loss = 0.0
    batches = range(0, len(rows), batch_size)
    for start in tqdm(batches, desc="SigLIP 학습", unit="배치"):
        batch = rows[start:start + batch_size]
        images = [read_image(row["image_path"]) for row in batch]
        pixels = processor(images=images, return_tensors="pt").pixel_values.to(network.device)
        tokens = tokenize(processor, [row["prompts"] for row in batch]).to(network.device)

        # 배치에서 같은 위치의 텍스트와 이미지를 정답 쌍으로, 나머지 조합을 오답 쌍으로 학습합니다.
        optimizer.zero_grad(set_to_none=True)
        loss = network(**tokens, pixel_values=pixels, return_loss=True).loss
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(batch)
    return total_loss / len(rows)


def train_siglip(args, device, train, valid, gallery, submission_dir):
    """1단계를 학습해 최고 점수 가중치를 models/에 저장하고, 그 가중치를 다시 불러와 반환합니다."""
    config = {**DEFAULT_CONFIG, "image_workers": args.workers}
    if args.epochs == 0:
        print("1단계 SigLIP 학습 생략: 제출 폴더의 기존 가중치를 사용합니다.", flush=True)
    else:
        network = SiglipModel.from_pretrained(args.model).to(device)
        processor = AutoProcessor.from_pretrained(args.model)
        # 기본 예제에서는 두 인코더의 출력 헤드만 학습해 필요한 GPU 메모리를 줄입니다.
        network.requires_grad_(False)
        network.text_model.head.requires_grad_(True)
        network.vision_model.head.requires_grad_(True)
        optimizer = torch.optim.AdamW((p for p in network.parameters() if p.requires_grad), lr=args.lr)
        best = -1.0
        for epoch in range(1, args.epochs + 1):
            loss = train_siglip_epoch(network, processor, train, optimizer, args.batch_size)
            model = {"siglip": network, "processor": processor, "reranker": None, "config": config}
            metrics = evaluate(model, valid, gallery)[0][0.0]
            print(f"[1단계] 에포크 {epoch} | loss {loss:.4f} | {describe(metrics)}", flush=True)
            if metrics["score"] > best:
                best = metrics["score"]
                save_pretrained_dir([network, processor], submission_dir / "models")
                print(f"1단계 가중치 저장: {submission_dir / 'models'}", flush=True)
        del network, optimizer
        if device == "cuda":
            torch.cuda.empty_cache()

    checkpoint = submission_dir / "models"
    if not (checkpoint / "config.json").is_file():
        raise FileNotFoundError(f"{checkpoint}에 SigLIP 가중치가 없습니다. --epochs를 1 이상으로 주세요.")
    network = SiglipModel.from_pretrained(checkpoint, local_files_only=True).to(device)
    processor = AutoProcessor.from_pretrained(checkpoint, local_files_only=True)
    return network.eval(), processor


# ---------------------------------------------------------------- 2단계: BLIP-2 재정렬기

def mine_hard_negatives(model, train, k):
    """1단계가 헷갈려 하는 상대를 양방향으로 k개씩 찾습니다(정답 제외, 유사도 내림차순).

    image_pool[i]: 학습 프롬프트 i와 가까운 학습 이미지 — 실전에서 재정렬기가 받을 후보와 같은 분포(대부분 형제 이미지)
    text_pool[i]:  학습 이미지 i와 가까운 학습 프롬프트 — 형제의 실제 프롬프트, 이미지 i에 대한 자연스러운 오답 문장
    """
    with torch.no_grad():
        image_vectors = encode_images(model, [row["image_path"] for row in train])
        text_vectors = encode_texts(model, [row["prompts"] for row in train])
        similarity = text_vectors @ image_vectors.T
        similarity.fill_diagonal_(float("-inf"))
        k = min(k, len(train) - 1)
        image_pool = similarity.topk(k, dim=1).indices.cpu().tolist()
        text_pool = similarity.T.topk(k, dim=1).indices.cpu().tolist()
    return image_pool, text_pool


def pick_hard(pool, count, rng):
    """유사도 순 후보에서 count개를 고릅니다. 절반(올림)은 가장 헷갈리는 순서대로 고정하고, 나머지는 남은 후보에서 무작위로 뽑습니다.

    예전처럼 Top-20에서 전부 무작위로 뽑으면 가장 헷갈리는 형제가 들어갈 확률이 에포크당 35%뿐이었습니다.
    """
    count = min(count, len(pool))
    fixed = (count + 1) // 2
    return pool[:fixed] + rng.sample(pool[fixed:], count - fixed)


def show_negative_examples(train, pools, noun_forms, args, flip_of=None, count=2):
    """학습 전에 오답이 어떻게 만들어지는지 통계와 예시를 보여 줍니다(로그 확인용, 학습 난수에는 영향 없음)."""
    image_pool, text_pool = pools
    rng = random.Random(0)
    kinds, total, doubles = Counter(), 0, 0
    for row in train:
        for kind, _ in make_text_negatives(row["prompts"], rng, args.text_negatives, noun_forms,
                                           args.double_edit_ratio, with_kind=True):
            total += 1
            doubles += "+" in kind
            for part in kind.split(" + "):
                kinds[part if part.startswith("relation") else part.split()[0]] += 1
    share = ", ".join(f"{k} {v / max(1, sum(kinds.values())):.0%}" for k, v in kinds.most_common())
    print(f"  규칙 오답 {total}개(에포크당), 두 가지 변경 {doubles / max(1, total):.0%} | 바뀐 항목: {share}", flush=True)
    print(f"  프롬프트당: 형제 이미지 {args.image_negatives}, 규칙 문장 {args.text_negatives}, "
          f"형제 프롬프트 {args.sibling_text_negatives}, 좌우 반전 짝 {len(flip_of or {})}/{len(train)}개 프롬프트", flush=True)
    for i in range(min(count, len(train))):
        print(f"  [예시 {i + 1}] 원문: {train[i]['prompts']}", flush=True)
        for kind, text in make_text_negatives(train[i]["prompts"], rng, args.text_negatives, noun_forms,
                                              args.double_edit_ratio, with_kind=True):
            print(f"    규칙 오답 <{kind}>: {text}", flush=True)
        for j in pick_hard(text_pool[i], args.sibling_text_negatives, rng):
            print(f"    형제 프롬프트: {train[j]['prompts']}", flush=True)


def flip_eligible(prompt):
    """좌우 반전 짝을 만들 수 있는 프롬프트(left/right 관계가 있음). 이미지를 뒤집으면 left와 right만 정확히 바뀝니다."""
    return bool(re.search(r"(?<![\w-])(left|right)(?![\w-])", prompt, re.IGNORECASE))


def build_rerank_batch(batch, train, image_pool, text_pool, args, rng, noun_forms, flip_of=None):
    """재정렬기 학습 배치의 (이미지 인덱스, 문장, 목록 그룹)을 만듭니다. 그룹마다 0번이 정답입니다.

    이미지 그룹: 프롬프트 하나에 대해 [정답 이미지, 형제 이미지들, 좌우 반전한 정답 이미지]  — 테스트와 같은 상황
    텍스트 그룹: 정답 이미지 하나에 대해 [원문, 규칙 오답 문장(한 가지·두 가지 변경), 형제의 실제 프롬프트들]
    반전 그룹:   좌우 반전 이미지 하나에 대해 [left↔right를 바꾼 문장, 원문]
    flip_of: 학습 인덱스 → 캐시 안의 좌우 반전 특징 인덱스
    """
    flip_of = flip_of or {}
    image_index, texts, groups = [], [], []

    def add(image, text):
        image_index.append(image)
        texts.append(text)
        return len(texts) - 1

    for i in batch:
        prompt = train[i]["prompts"]
        group = [add(j, prompt) for j in [i] + pick_hard(image_pool[i], args.image_negatives, rng)]
        flipped = add(flip_of[i], prompt) if i in flip_of else None
        if flipped is not None:
            group.append(flipped)
        groups.append(group)
        negatives = make_text_negatives(prompt, rng, args.text_negatives, noun_forms, args.double_edit_ratio)
        negatives += [train[j]["prompts"] for j in pick_hard(text_pool[i], args.sibling_text_negatives, rng)]
        if negatives:
            groups.append([group[0]] + [add(i, text) for text in negatives])   # 원문-정답 쌍은 위에서 이미 넣었습니다.
        if flipped is not None:
            swapped = _swap(prompt, "left", "right")
            if swapped != prompt:
                groups.append([add(flip_of[i], swapped), flipped])
    return image_index, texts, groups


def cache_blip_images(blip, blip_processor, rows, workers, flip_rows=()):
    """학습 이미지(와 좌우 반전 이미지)의 ViT-g 특징을 한 번만 계산해 CPU에 둡니다.

    ViT-g는 동결하므로 에포크마다 다시 계산할 필요가 없습니다. GPU 대신 CPU에 두어 학습 중 GPU 메모리를 2~3GB 아끼고,
    배치마다 필요한 특징(약 0.7MB × 쌍 수)만 GPU로 옮깁니다. 반환 순서: rows 전체, 그다음 flip_rows 순서의 반전 이미지.
    """
    items = [(row["image_path"], False) for row in rows] + [(rows[i]["image_path"], True) for i in flip_rows]
    paths = [path for path, _ in items]
    flips = torch.tensor([flip for _, flip in items], dtype=torch.bool)
    cache, start = None, 0
    with torch.no_grad():   # inference_mode로 만든 텐서는 역전파 입력으로 쓸 수 없어서 no_grad를 씁니다.
        for pixels in tqdm(iter_pixel_batches(paths, blip_processor.image_processor, 32, workers),
                           total=math.ceil(len(paths) / 32), desc="BLIP-2 이미지 특징 캐시", unit="배치"):
            mask = flips[start:start + len(pixels)]
            if mask.any():
                pixels[mask] = pixels[mask].flip(-1)   # 좌우 반전(정규화 뒤에 뒤집어도 같습니다)
            embeds = blip_image_embeds(blip, pixels).cpu()
            if cache is None:   # 미리 한 번에 잡아 두어 합치는 동안 메모리가 두 배로 뛰지 않게 합니다.
                cache = torch.empty((len(paths), *embeds.shape[1:]), dtype=embeds.dtype)
            cache[start:start + len(embeds)] = embeds
            start += len(embeds)
    return cache


def enable_qformer_checkpointing(blip):
    """Q-Former 층마다 gradient checkpointing을 켭니다. 역전파용 중간값을 저장하지 않고 다시 계산해 활성화 메모리를 크게 줄입니다.

    Blip2ForImageTextRetrieval은 gradient_checkpointing_enable()을 막아 두어 층에 직접 설정합니다. 학습 모드에서만 동작하므로
    검증(eval)과 추론에는 영향이 없습니다.
    """
    from transformers.modeling_layers import GradientCheckpointingLayer

    checkpoint = functools.partial(torch.utils.checkpoint.checkpoint, use_reentrant=False)
    layers = [module for module in blip.qformer.modules() if isinstance(module, GradientCheckpointingLayer)]
    for layer in layers:
        layer.gradient_checkpointing = True
        layer._gradient_checkpointing_func = checkpoint
    return len(layers)


def amp_dtype(device):
    """혼합 정밀도 자료형. bf16을 지원하는 GPU(A100, L4 등 Ampere 이후)는 bf16, T4 같은 이전 세대는 fp16입니다."""
    if device != "cuda":
        return None
    return torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 else torch.float16


def train_reranker_epoch(blip, blip_processor, train, cache, pools, noun_forms, optimizer, scheduler, scaler, args,
                         rng, device, flip_of=None):
    blip.train()
    blip.vision_model.eval()
    params = [p for p in blip.parameters() if p.requires_grad]
    dtype = amp_dtype(device)
    autocast = torch.autocast(device_type="cuda", dtype=dtype) if dtype else contextlib.nullcontext()
    order = list(range(len(train)))
    rng.shuffle(order)
    total_loss = 0.0
    for start in tqdm(range(0, len(order), args.rerank_batch), desc="재정렬기 학습", unit="배치"):
        batch = order[start:start + args.rerank_batch]
        image_index, texts, groups = build_rerank_batch(batch, train, *pools, args, rng, noun_forms, flip_of)

        tokens = blip_tokenize(blip_processor, texts, DEFAULT_CONFIG["rerank_text_tokens"]).to(device)
        embeds = cache[torch.tensor(image_index, device=cache.device)].to(device)   # CPU 캐시에서 이 배치 몫만 GPU로
        with autocast:
            scores = itm_scores(blip, embeds, tokens.input_ids, tokens.attention_mask)
        # 목록 단위 교차 엔트로피: 그룹마다 0번(정답)이 가장 높은 점수를 받도록 합니다.
        target = torch.zeros(1, dtype=torch.long, device=scores.device)
        loss = torch.stack([F.cross_entropy(scores[group].unsqueeze(0), target) for group in groups]).mean()

        # fp16에서는 작은 그래디언트가 0으로 사라지지 않도록 GradScaler로 손실을 키웠다가 되돌립니다(bf16·fp32에서는 그대로 통과).
        optimizer.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()
        total_loss += loss.item() * len(batch)
    return total_loss / len(train)


def train_reranker(args, device, train, valid, gallery, siglip, processor, submission_dir):
    print(f"2단계: BLIP-2 재정렬기 불러오기 ({args.reranker_model})", flush=True)
    blip = Blip2ForImageTextRetrieval.from_pretrained(args.reranker_model).to(device)
    blip_processor = AutoProcessor.from_pretrained(args.reranker_model)
    if device == "cuda":
        blip.vision_model.half()   # 동결한 ViT-g는 fp16으로 두어 메모리와 시간, 제출 용량을 줄입니다.
    # ViT-g는 동결하고 Q-Former(텍스트 임베딩, 질의 토큰 포함)와 ITM 헤드만 학습합니다.
    blip.requires_grad_(False)
    for module in (blip.qformer, blip.embeddings, blip.itm_head):
        module.requires_grad_(True)
    blip.query_tokens.requires_grad_(True)

    config = {**DEFAULT_CONFIG, "rerank": True, "rerank_k": args.rerank_k, "image_workers": args.workers}
    model = {"siglip": siglip, "processor": processor, "reranker": (blip, blip_processor), "config": config}
    best = {"score": -1.0}

    def check(label):
        results, stage1_recall = evaluate(model, valid, gallery, FUSION_WEIGHTS)
        stage1 = results[0.0]
        weight, metrics = max(results.items(), key=lambda item: (item[1]["score"], -item[0]))
        gained = int((~stage1["top1"] & metrics["top1"]).sum())
        lost = int((stage1["top1"] & ~metrics["top1"]).sum())
        recall_text = " | ".join(f"R@{k} {value:.4f}" for k, value in stage1_recall.items())
        print(f"[2단계 {label}] 1단계 후보 재현율 (재정렬 상한) {recall_text}", flush=True)
        print(f"  1단계만        | {describe(stage1)}", flush=True)
        print(f"  재정렬만 (w=1) | {describe(results[1.0])}", flush=True)
        print(f"  최적 w={weight:.1f}    | {describe(metrics)} | 1위 교정 +{gained} / 훼손 -{lost}", flush=True)
        if metrics["score"] > best["score"]:
            best["score"] = metrics["score"]
            use_rerank = weight > 0
            if use_rerank:
                save_pretrained_dir([blip, blip_processor], submission_dir / "reranker")
            write_pipeline(submission_dir, {**config, "rerank": use_rerank, "rerank_weight": weight})
            print(f"  저장: pipeline.json (rerank={use_rerank}, w={weight:.1f})"
                  + (f", {submission_dir / 'reranker'}" if use_rerank else ""), flush=True)

    # 학습 전(zero-shot) 성능부터 재서, 재정렬이 1단계보다 나은지 먼저 확인합니다.
    check("zero-shot")
    if args.rerank_epochs == 0:
        return

    print("재정렬기 학습 데이터 준비: 1단계로 형제 이미지·형제 프롬프트 찾기", flush=True)
    pools = mine_hard_negatives(model, train, args.negative_pool)
    noun_forms = build_noun_forms([row["prompts"] for row in train])
    flip_rows = [i for i, row in enumerate(train) if flip_eligible(row["prompts"])] if args.flip_negatives else []
    flip_of = {i: len(train) + k for k, i in enumerate(flip_rows)}
    show_negative_examples(train, pools, noun_forms, args, flip_of)
    cache = cache_blip_images(blip, blip_processor, train, args.workers, flip_rows)
    print(f"  ViT-g 특징 캐시(CPU): 이미지 {len(train)}장 + 좌우 반전 {len(flip_rows)}장, "
          f"{cache.numel() * cache.element_size() / 1e9:.1f}GB", flush=True)
    if args.grad_checkpoint:
        print(f"  Q-Former gradient checkpointing: {enable_qformer_checkpointing(blip)}개 층", flush=True)
    if device == "cuda":
        torch.cuda.empty_cache()
        print(f"  학습 시작 전 GPU 사용량 {torch.cuda.memory_allocated() / 1e9:.1f}GB", flush=True)

    params = [p for p in blip.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=args.rerank_lr, weight_decay=0.05)
    total_steps = math.ceil(len(train) / args.rerank_batch) * args.rerank_epochs
    warmup = max(1, total_steps // 20)
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: min(1.0, (step + 1) / warmup) * 0.5 * (1 + math.cos(math.pi * step / total_steps)))
    scaler = torch.amp.GradScaler("cuda" if device == "cuda" else "cpu", enabled=amp_dtype(device) == torch.float16)
    print(f"재정렬기 혼합 정밀도: {amp_dtype(device) or 'fp32'}", flush=True)
    rng = random.Random(args.seed)
    for epoch in range(1, args.rerank_epochs + 1):
        loss = train_reranker_epoch(blip, blip_processor, train, cache, pools, noun_forms, optimizer, scheduler,
                                    scaler, args, rng, device, flip_of)
        peak = f" | GPU 최대 {torch.cuda.max_memory_allocated() / 1e9:.1f}GB" if device == "cuda" else ""
        print(f"[2단계] 에포크 {epoch} | loss {loss:.4f}{peak}", flush=True)
        check(f"에포크 {epoch}")


# ---------------------------------------------------------------- 실행

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("haikuthon-train"))
    parser.add_argument("--output", type=Path, help="함께 생성할 제출 ZIP 경로 (예: sample_submission.zip)")
    parser.add_argument("--submission-dir", type=Path, default=DEFAULT_SUBMISSION_DIR,
                        help="가중치와 pipeline.json을 저장할 제출 폴더")
    parser.add_argument("--device", choices=["cuda", "mps", "cpu"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--workers", type=int, default=8, help="이미지 디코딩 스레드 수")
    parser.add_argument("--val-gallery", choices=["all", "valid"], default="all",
                        help="검증 후보 이미지. all: 검증+학습 이미지 4,000장(기본, 형제 그룹이 갖춰져 공개 점수와 비슷한 난이도), "
                             "valid: 검증 이미지 800장만(이전 방식, 점수가 부풀려짐)")
    # 1단계 SigLIP
    parser.add_argument("--model", default=MODEL_ID, help="SigLIP 사전 학습 모델 이름 또는 로컬 경로")
    parser.add_argument("--epochs", type=int, default=1, help="SigLIP 에포크. 0이면 제출 폴더의 기존 가중치를 씁니다.")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-5)
    # 2단계 BLIP-2 재정렬기
    parser.add_argument("--no-rerank", action="store_true", help="재정렬기 없이 1단계만 제출합니다.")
    parser.add_argument("--reranker-model", default=RERANKER_ID, help="BLIP-2 ITM 모델 이름 또는 로컬 경로")
    parser.add_argument("--rerank-epochs", type=int, default=2, help="0이면 학습 없이(zero-shot) 평가·저장합니다.")
    parser.add_argument("--rerank-k", type=int, default=32,
                        help="재정렬할 1단계 최대 후보 수 (5개씩 묶어 시간 예산 안에서 최대한, 테스트 형제 그룹 약 32장)")
    parser.add_argument("--rerank-batch", type=int, default=8, help="재정렬기 학습 배치의 프롬프트 수")
    parser.add_argument("--rerank-lr", type=float, default=1e-5)
    parser.add_argument("--image-negatives", type=int, default=9,
                        help="프롬프트당 형제 이미지 오답 수 (절반은 가장 헷갈리는 순서로 고정, 나머지는 무작위). "
                             "학습 데이터의 형제 그룹은 최대 8장이라 형제를 대부분 담습니다.")
    parser.add_argument("--negative-pool", type=int, default=32,
                        help="형제 이미지·형제 프롬프트를 고를 1단계 Top-N (학습용). 추론 후보 범위(--rerank-k)와 맞춰 "
                             "재정렬기가 21~32위 같은 후보도 학습 때 보게 합니다.")
    parser.add_argument("--text-negatives", type=int, default=4,
                        help="정답 이미지당 규칙으로 만든 오답 문장 수 (교체형·치환형, 형제 분석 비율대로)")
    parser.add_argument("--double-edit-ratio", type=float, default=0.5,
                        help="규칙 오답 중 두 가지를 함께 바꾼 문장의 비율 (형제 쌍의 47%%가 두 가지가 다름)")
    parser.add_argument("--sibling-text-negatives", type=int, default=4,
                        help="정답 이미지당 형제의 실제 프롬프트 오답 수 (절반은 가장 헷갈리는 순서로 고정)")
    parser.add_argument("--flip-negatives", action=argparse.BooleanOptionalAction, default=True,
                        help="left/right가 있는 프롬프트에 좌우 반전 이미지 짝을 추가 (--no-flip-negatives로 끔)")
    parser.add_argument("--grad-checkpoint", action=argparse.BooleanOptionalAction, default=True,
                        help="Q-Former gradient checkpointing으로 학습 GPU 메모리 절약 (--no-grad-checkpoint로 끔)")
    args = parser.parse_args()

    submission_dir = args.submission_dir.resolve()
    if args.output and (args.output.suffix.lower() != ".zip" or args.output.resolve().is_relative_to(submission_dir)):
        parser.error("--output은 제출 폴더 밖의 .zip 파일로 지정해 주세요.")
    if args.epochs < 0 or args.rerank_epochs < 0 or args.batch_size < 1 or args.lr <= 0:
        parser.error("epochs, rerank-epochs는 0 이상, batch-size와 lr은 양수여야 합니다.")
    if args.rerank_k < 5 or args.rerank_batch < 1 or args.rerank_lr <= 0:
        parser.error("rerank-k는 5 이상, rerank-batch와 rerank-lr은 양수여야 합니다.")
    if args.negative_pool < 1:
        parser.error("negative-pool은 1 이상이어야 합니다.")
    if min(args.image_negatives, args.text_negatives, args.sibling_text_negatives) < 0:
        parser.error("image-negatives, text-negatives, sibling-text-negatives는 0 이상이어야 합니다.")
    if not 0 <= args.double_edit_ratio <= 1:
        parser.error("double-edit-ratio는 0~1 사이여야 합니다.")
    device = args.device
    if device is None:
        if torch.cuda.is_available():
            device = "cuda"
        elif torch.backends.mps.is_available():
            device = "mps"
        else:
            device = "cpu"
    torch.manual_seed(args.seed)
    prepare_submission_dir(submission_dir)

    train, valid = load_and_split(args.data_dir, args.seed)
    # 학습 이미지는 검증 때 오답 후보로만 쓰입니다. 학습·하드 네거티브 마이닝에는 영향이 없습니다.
    gallery = train if args.val_gallery == "all" else []
    print(f"학습 {len(train):,}쌍 / 검증 {len(valid):,}쌍 (후보 이미지 {len(valid) + len(gallery):,}장) / 장치 {device}",
          flush=True)

    siglip, processor = train_siglip(args, device, train, valid, gallery, submission_dir)
    if args.no_rerank:
        write_pipeline(submission_dir, {**DEFAULT_CONFIG, "rerank": False, "image_workers": args.workers})
        print("재정렬기 사용 안 함: pipeline.json에 rerank=false를 기록했습니다.", flush=True)
    else:
        train_reranker(args, device, train, valid, gallery, siglip, processor, submission_dir)

    if args.output:
        make_zip(submission_dir, args.output)
        print(f"제출 ZIP 저장: {args.output.resolve()}", flush=True)


if __name__ == "__main__":
    main()
