# 2026 HAIKUTHON · SigLIP 스타터킷

영문 프롬프트와 가장 잘 맞는 이미지 5장을 찾는 예제입니다. `sample_submission/`에는 공개 학습 데이터로 학습한 SigLIP Base 예제 모델이 들어 있습니다. `train.py`를 실행하면 직접 학습한 모델로 이 폴더를 갱신합니다.

```text
starterkit/
├── train.py                   # 학습 및 검증
├── requirements.txt           # 참가자 학습 환경
├── README.md
├── sample_submission.zip      # 모델 제출 페이지에 바로 올릴 예제
└── sample_submission/
    ├── model.py               # 평가 서버가 호출하는 load_model과 predict
    ├── requirements.txt       # 추론에 사용하는 패키지
    └── models/
        ├── model.safetensors      # 학습한 가중치
        ├── config.json            # 모델 구조
        ├── processor_config.json  # 이미지 전처리 설정
        ├── tokenizer_config.json  # 토크나이저 설정
        ├── spiece.model           # 토크나이저 어휘
        └── LICENSE-SigLIP.txt
```

## 1. 환경 준비

Python 3.12 환경에서 스타터킷 폴더로 이동한 뒤 실행하세요. NVIDIA GPU, Apple Silicon GPU, CPU 순으로 사용 가능한 장치를 선택합니다.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows PowerShell에서는 두 번째 줄에 `.\.venv\Scripts\Activate.ps1`을 사용하세요. NVIDIA GPU를 쓰는 경우 `python -c "import torch; print(torch.cuda.is_available())"`로 GPU 인식을 확인할 수 있습니다.

## 2. 학습 데이터 받기

```bash
hf download KimWooJin/26-haikuthon-train --repo-type dataset --include "prompts.jsonl" --include "images/*.png" --local-dir haikuthon-train
```

`prompts.jsonl`에서 `id`가 `"0006"`인 행의 영문 프롬프트(`prompts`)는 `images/0006.png`와 한 쌍입니다. 파일을 찾을 때는 ID 앞자리의 0을 유지합니다. [공개 학습 데이터](https://huggingface.co/datasets/KimWooJin/26-haikuthon-train)

## 3. 학습하고 검증하기

```bash
python train.py --data-dir haikuthon-train
```

1. **분할** — 시드 42로 이미지·프롬프트 쌍을 무작위 배정합니다. 학습 3,200쌍, 검증 800쌍이며, 각 집합 안에서는 숫자 ID 오름차순으로 처리합니다. 에포크 사이에도 이 순서를 유지합니다.
2. **학습** — 약 203M 파라미터의 SigLIP Base를 불러와 이미지·텍스트 출력 헤드만 업데이트합니다. 같은 배치에서 서로 짝인 텍스트와 이미지의 점수를 높이고 다른 조합의 점수를 낮추는 SigLIP 손실을 사용합니다. 기본 설정은 1에포크, 배치 크기 16, 학습률 `1e-5`입니다. [기본 모델](https://huggingface.co/google/siglip-base-patch16-224)
3. **검증** — 각 검증 프롬프트에 대해 검증 이미지 800장과 학습 이미지 3,200장, 총 4,000장에서 Top-5를 검색합니다(팀 수정, 아래 5절 참고. `--val-gallery valid`이면 예전처럼 검증 이미지 800장만). 정답 이미지가 1위인 비율인 Recall@1, 정답 순위에 따른 NDCG@5, 두 지표의 산술평균을 출력합니다.
4. **저장** — 평균 점수가 가장 높은 에포크의 가중치, 토크나이저, 전처리 설정을 `sample_submission/models/`에 저장합니다. 다시 학습하면 이 폴더의 예제 가중치가 새 학습 결과로 교체됩니다.

학습 횟수나 배치 크기는 `--epochs 3 --batch-size 8`처럼 바꿀 수 있습니다. 모델은 처음 학습할 때 Hugging Face에서 내려받습니다. 이미 다운로드했다면 `--model`에 모델 폴더를 지정할 수 있습니다.

기본 설정으로 Apple Silicon에서 1에포크 학습한 예제의 검증 결과는 Recall@1 **0.6925**, NDCG@5 **0.8752**, 평균 **0.7839**입니다. 공개 학습 데이터에서 따로 둔 800쌍을 검증 이미지 800장 안에서 찾은 값입니다. 같은 가중치를 4,000장 후보로 재면 Recall@1 0.257, NDCG@5 0.579, Recall@5 0.864입니다.

## 4. 제출하기

동봉된 **`sample_submission.zip`**을 모델 제출 페이지에 바로 업로드할 수 있습니다. 예제 파일을 수정했다면 `sample_submission/` 안의 `model.py`, `requirements.txt`, `models/`를 선택해 다시 압축하세요. `model.py`는 ZIP 최상위에 둡니다. 이 예제는 `models/`에서 가중치와 설정을 읽으므로 폴더 구조를 바꿀 때는 `model.py`의 로딩 경로와 `train.py`의 저장 경로도 맞춰 주세요. 직접 학습하면서 ZIP까지 만들려면 스타터킷 폴더에서 아래 명령을 실행하세요.

```bash
python train.py --data-dir haikuthon-train --output sample_submission.zip
```

생성된 `sample_submission.zip`을 모델 제출 페이지에 업로드하세요. 평가 서버는 `load_model()`로 모델을 복원하고 `predict()`에 프롬프트와 전체 후보 이미지를 전달합니다. Kaggle용 CSV는 평가가 끝난 뒤 모델 제출 사이트에서 다운로드할 수 있습니다.

학습·검증 로직을 바꾸려면 `train.py`를, 검색 방법을 바꾸려면 `sample_submission/model.py`를 수정하세요. 검증과 서버 평가 모두 같은 `predict()`를 사용합니다.

## 5. 2단계 재정렬 (BLIP-2) — 팀 수정본

원본 스타터킷 파일은 `backup_baseline/`에 있습니다.

```
1단계 SigLIP: 후보 전체 → 프롬프트별 Top-K (--rerank-k, 재정렬할 최대 후보 수)
2단계 BLIP-2 ITM (Salesforce/blip2-itm-vit-g): Top-K 쌍을 다시 채점
최종 점수 = w × z(재정렬 점수) + (1 − w) × z(1단계 점수)   (쿼리별 z-정규화, w는 검증으로 선택)
```

**학습 순서 (`python train.py --data-dir haikuthon-train --output submission.zip`)**
1. 1단계 SigLIP 학습 (기존과 같음, `--epochs 0`이면 생략하고 제출 폴더의 기존 가중치 사용)
2. BLIP-2 zero-shot 평가 → 1단계보다 나은지 먼저 확인
3. 형제 오답 준비 (v2): 데이터는 한 가지만 다른 형제 그룹이라, 형제를 구분하는 오답을 양방향으로 만듭니다. 학습 시작 전에 예시 2개가 로그에 찍힙니다.
   - **이미지 그룹** (프롬프트 하나 vs 형제 이미지들, 테스트와 같은 상황): 1단계 Top-20(`--negative-pool`)에서 `--image-negatives`(7)장. 절반(4장)은 가장 헷갈리는 순서대로 고정하고, 나머지는 무작위로 뽑습니다.
   - **텍스트 그룹** (정답 이미지 하나 vs 틀린 문장들):
     - 형제의 실제 프롬프트 `--sibling-text-negatives`(3)개: 이미지와 가장 가까운 학습 프롬프트이고, 절반은 고정합니다.
     - 규칙으로 만든 문장 `--text-negatives`(3)개.
       - 교체형(단어는 그대로, 연결만 바뀜): 좌우·위아래, 두 사물의 색·무늬·자세·열림/닫힘 맞바꾸기
       - 치환형(한 단어만 바뀜): 색·무늬·자세·열림/닫힘 하나 바꾸기, one ↔ two(복수형과 is/are까지 맞춤)
     - 스타일·시점·조명 교체는 형제끼리 거의 다르지 않아(오류의 7%) 뺐습니다. 문법이 어색해지는 경우(같은 명사를 다시 가리키는 문장, 동물에 kneeling)는 만들지 않습니다.
4. ViT-g 동결, Q-Former·ITM 헤드만 목록 단위 교차 엔트로피로 학습 (`--rerank-epochs`, 기본 2). 배치당 ITM 쌍이 약 112개(이전 약 88개)라, GPU 메모리가 부족하면 `--rerank-batch`를 줄이세요.
5. 매 에포크 w = 0.0~1.0을 검증으로 고르고, 최고 점수일 때 `reranker/`와 `pipeline.json` 저장. 최적 w가 0이면 재정렬을 끄고 ZIP에서 `reranker/`를 뺍니다.

주요 옵션: `--rerank-k`, `--rerank-epochs`, `--rerank-lr`, `--image-negatives`, `--negative-pool`, `--text-negatives`, `--sibling-text-negatives`, `--no-rerank`, `--reranker-model`, `--submission-dir`, `--workers`, `--val-gallery`

**검증 방식 (`--val-gallery`, 기본 `all`)**: 데이터는 한 가지(위아래, 개수, 색 바인딩, 자세)만 다른 형제 이미지 그룹(최대 8장)으로 되어 있습니다. 무작위 분할을 하면 형제 대부분이 학습 쪽에 들어가서, 검증 이미지 800장만 후보로 두면 너무 쉽습니다(1단계 Recall@5 1.00, 공개 테스트 0.46). 그래서 학습 이미지 3,200장을 오답 후보로 함께 넣어 4,000장에서 검색합니다. 정답은 항상 해당 검증 이미지이고, 학습과 하드 네거티브 마이닝은 바뀌지 않습니다. 2단계 로그의 `1단계 후보 재현율`(R@5/10/15/20)은 재정렬이 도달할 수 있는 상한이므로 `--rerank-k`를 고를 때 참고하세요. 한계: 후보에 학습 때 본 이미지가 섞여 있어서 테스트(프롬프트 8,000개, 이미지 16,000장)와 완전히 같지는 않습니다.

**추론 (`model.py`)**: 이미지 디코딩은 멀티스레드로 하고 다음 배치를 미리 읽습니다. 재정렬은 순위 묶음 단위로 진행합니다. 모든 질의의 1~5위를 먼저 채점하고(여기까지가 기존 K=5와 같은 결과), 시간이 남으면 6~10위, 11~15위 … `rerank_k`까지 넓힙니다. ViT-g 특징은 캐시(GPU 여유 메모리 → CPU 여유 메모리의 절반, 이미지당 약 0.7MB)에 두어 묶음이 바뀌어도 이미지당 한 번만 계산합니다. 캐시에 담지 못한 이미지는 다시 계산하므로 느려질 뿐 점수는 같습니다. `pipeline.json`의 `time_budget_sec`(기본 840초, `load_model` 시작 기준. 서버 제한 15분에서 시작·마무리 여유 1분을 뺀 값)를 넘기면 멈추고, 질의마다 앞에서부터 빠짐없이 채점된 묶음까지만 재정렬에 씁니다. 1~5위도 못 끝낸 질의는 1단계 순위를 씁니다. 묶음마다 `재정렬 6~10위 완료: …` 로그를 출력합니다. `pipeline.json`이나 `reranker/`가 없으면 기존처럼 1단계만 씁니다.

**주의**
- 학습은 GPU(L4 등)에서 하세요. BLIP-2는 처음 실행할 때 약 4.6GB를 내려받습니다.
- 제출 ZIP이 약 3GB로 커집니다(SigLIP 0.8GB + BLIP-2 약 2.4GB). 제출 용량 제한을 확인하세요.
- Windows에서 경로에 한글이 있으면 sentencepiece가 토크나이저를 읽지 못합니다. 영문 경로(예: `C:\Users\Public\haikuthon` 링크)에서 실행하세요.
